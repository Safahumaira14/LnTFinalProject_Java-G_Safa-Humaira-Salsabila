/**
 * 
 */
/**
 * 
 */
module final_ptpudding {
	requires java.desktop;
	requires java.sql;
}