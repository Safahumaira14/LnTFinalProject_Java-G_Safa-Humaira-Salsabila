package final_ptpudding;
import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {
    public MainMenu() {
        super("Menu Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLayout(new BorderLayout(10, 10));

        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnCreate = new JButton("Create Menu");
        JButton btnView = new JButton("View Menus");
        JButton btnEdit = new JButton("Edit Menu");
        JButton btnDelete = new JButton("Delete Menu");

        btnCreate.addActionListener(e -> new CreateMenu(this));
        btnView.addActionListener(e -> new ViewMenu(this));
        btnEdit.addActionListener(e -> new EditMenu(this));
        btnDelete.addActionListener(e -> new DeleteMenu(this));

        buttonPanel.add(btnCreate);
        buttonPanel.add(btnView);
        buttonPanel.add(btnEdit);
        buttonPanel.add(btnDelete);

        add(buttonPanel, BorderLayout.CENTER);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        new MainMenu();
    }
}
