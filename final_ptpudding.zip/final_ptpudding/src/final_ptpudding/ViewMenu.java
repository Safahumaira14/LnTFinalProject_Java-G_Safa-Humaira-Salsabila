package final_ptpudding;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ViewMenu extends JDialog {
    public ViewMenu(JFrame parent) {
        super(parent, "View Menus", true);
        setSize(450, 300);
        CardLayout cardLayout = new CardLayout();
        setLayout(cardLayout);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        JPanel cardPanel = new JPanel(cardLayout);
        cardPanel.add(scrollPane, "View");

        add(cardPanel);
        loadMenuData(textArea);
        setVisible(true);
    }

    private void loadMenuData(JTextArea textArea) {
        StringBuilder sb = new StringBuilder();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/menudb", "root", "menuitems");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM MenuItems")) {
            while (rs.next()) {
                sb.append("Kode Menu: ").append(rs.getString("KodeMenu")).append(", ");
                sb.append("Nama Menu: ").append(rs.getString("NamaMenu")).append(", ");
                sb.append("Harga Menu: Rp. ").append(rs.getDouble("HargaMenu")).append(", ");
                sb.append("Stok Menu: ").append(rs.getInt("StokMenu")).append("\n");
            }
            textArea.setText(sb.toString());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}

