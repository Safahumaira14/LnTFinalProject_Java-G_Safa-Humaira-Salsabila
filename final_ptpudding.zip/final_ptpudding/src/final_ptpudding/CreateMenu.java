package final_ptpudding;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CreateMenu extends JDialog {
    private JTextField txtKodeMenu, txtNamaMenu, txtHargaMenu, txtStokMenu;
    private JButton btnSubmit;

    public CreateMenu(JFrame parent) {
        super(parent, "Create Menu", true);
        setSize(350, 200);
        setLayout(new BorderLayout(5, 5));

        JPanel centerPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        txtKodeMenu = new JTextField();
        txtNamaMenu = new JTextField();
        txtHargaMenu = new JTextField();
        txtStokMenu = new JTextField();

        centerPanel.add(new JLabel("Kode Menu:"));
        centerPanel.add(txtKodeMenu);
        centerPanel.add(new JLabel("Nama Menu:"));
        centerPanel.add(txtNamaMenu);
        centerPanel.add(new JLabel("Harga Menu:"));
        centerPanel.add(txtHargaMenu);
        centerPanel.add(new JLabel("Stok Menu:"));
        centerPanel.add(txtStokMenu);

        btnSubmit = new JButton("Submit");
        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        southPanel.add(btnSubmit);
        
        add(centerPanel, BorderLayout.CENTER);
        add(southPanel, BorderLayout.SOUTH);

        btnSubmit.addActionListener(this::submitAction);
        setVisible(true);
    }

    private void submitAction(ActionEvent e) {
        String kodeMenu = txtKodeMenu.getText();
        String namaMenu = txtNamaMenu.getText();
        double hargaMenu;
        int stokMenu;

        try {
            hargaMenu = Double.parseDouble(txtHargaMenu.getText());
            stokMenu = Integer.parseInt(txtStokMenu.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid number format for Price or Stock", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/menudb", "root", "menuitems")) {
            String sql = "INSERT INTO MenuItems (KodeMenu, NamaMenu, HargaMenu, StokMenu) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, kodeMenu);
                pstmt.setString(2, namaMenu);
                pstmt.setDouble(3, hargaMenu);
                pstmt.setInt(4, stokMenu);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Menu item created successfully!");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
