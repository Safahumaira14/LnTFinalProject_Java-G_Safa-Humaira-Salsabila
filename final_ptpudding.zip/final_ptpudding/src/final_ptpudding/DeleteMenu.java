package final_ptpudding;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DeleteMenu extends JDialog {
    public DeleteMenu(JFrame parent) {
        super(parent, "Delete Menu", true);
        setSize(300, 150);
        BoxLayout boxLayout = new BoxLayout(getContentPane(), BoxLayout.Y_AXIS);
        setLayout(boxLayout);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        JLabel labelKode = new JLabel("Kode Menu:");
        JTextField txtKodeMenu = new JTextField(10);
        JButton btnDelete = new JButton("Delete");

        panel.add(labelKode);
        panel.add(txtKodeMenu);
        panel.add(btnDelete);

        add(panel);

        btnDelete.addActionListener(e -> {
            String kodeMenu = txtKodeMenu.getText();
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/menudb", "root", "menuitems");
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM MenuItems WHERE KodeMenu = ?")) {
                pstmt.setString(1, kodeMenu);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Menu item deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "No Menu item found with the provided code!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });


        setVisible(true);
    }
}
