package final_ptpudding;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EditMenu extends JDialog {
    private JTextField txtKodeMenu, txtNamaMenu, txtHargaMenu, txtStokMenu;
    private JButton btnUpdate;

    public EditMenu(JFrame parent) {
        super(parent, "Edit Menu", true);
        setSize(400, 300);
        GridBagLayout gridBagLayout = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        setLayout(gridBagLayout);

        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Kode Menu
        JLabel labelKode = new JLabel("Kode Menu:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(labelKode, gbc);

        txtKodeMenu = new JTextField(10);
        gbc.gridx = 1;
        add(txtKodeMenu, gbc);

        // Nama Menu
        JLabel labelNama = new JLabel("Nama Menu:");
        gbc.gridy = 1;
        gbc.gridx = 0;
        add(labelNama, gbc);

        txtNamaMenu = new JTextField(10);
        gbc.gridx = 1;
        add(txtNamaMenu, gbc);

        // Harga Menu
        JLabel labelHarga = new JLabel("Harga Menu:");
        gbc.gridy = 2;
        gbc.gridx = 0;
        add(labelHarga, gbc);

        txtHargaMenu = new JTextField(10);
        gbc.gridx = 1;
        add(txtHargaMenu, gbc);

        // Stok Menu
        JLabel labelStok = new JLabel("Stok Menu:");
        gbc.gridy = 3;
        gbc.gridx = 0;
        add(labelStok, gbc);

        txtStokMenu = new JTextField(10);
        gbc.gridx = 1;
        add(txtStokMenu, gbc);

        // Update button
        btnUpdate = new JButton("Update");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(btnUpdate, gbc);

        btnUpdate.addActionListener(e -> {
            String kodeMenu = txtKodeMenu.getText();
            String namaMenu = txtNamaMenu.getText();
            double hargaMenu;
            int stokMenu;
            try {
                hargaMenu = Double.parseDouble(txtHargaMenu.getText());
                stokMenu = Integer.parseInt(txtStokMenu.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers for price and stock", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/yourDatabase", "username", "password");
                 PreparedStatement pstmt = conn.prepareStatement("UPDATE MenuItems SET NamaMenu = ?, HargaMenu = ?, StokMenu = ? WHERE KodeMenu = ?")) {
                pstmt.setString(1, namaMenu);
                pstmt.setDouble(2, hargaMenu);
                pstmt.setInt(3, stokMenu);
                pstmt.setString(4, kodeMenu);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Menu item updated successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "No Menu item found with the provided code!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        setVisible(true);
    }
}
